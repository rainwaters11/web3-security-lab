# Web3 Security Lab — working title

A local, single-user training prototype for learning smart contract security through your own reasoning. The final product name is undecided.

## Run it

Requires Node.js 20 or later. No package installation is needed.

```bash
cd web3-security-lab
npm start
```

Open `http://127.0.0.1:3000`. The first exercise is a deliberately vulnerable Solidity vault. Map the actors and assets, write a suspected finding and invariant, request progressive hints, then compare with the reference. Notes autosave in this browser and can be exported as JSON.

To turn on the optional AI mentor, set `OPENAI_API_KEY` in your shell before starting the server, then enable the checkbox in the UI. `OPENAI_MODEL` can override the default `gpt-5-mini`. The key stays on the server. AI mentor calls send the training contract and your analysis to the OpenAI API; the app sets `store: false`. If the model cannot respond, the guided coach still works. Without a key, no API calls are made. The first release has no paid API requirement.

## What this release does

- A complete first challenge with code, prompts, hints, and reference reasoning.
- A finding notebook for a claim, an invariant, and test evidence.
- A guided mentor that asks for an invariant and call path, plus optional AI feedback.
- Local save and JSON export.

It does **not** execute Solidity, import untrusted repositories, grade PoCs, confirm findings automatically, or provide a professional security audit. The learner must run tests separately. Reference findings are revealed after a written attempt; the gate encourages effort but is not tamper resistant.

## Next build sequence

1. Add a Foundry training project for this vault, with a failing exploit demonstration and a fixed implementation. Run tests only in an isolated local training environment.
2. Add 4–5 curated challenges across access control, accounting, signatures, and external calls; attach expected invariants and test prompts.
3. Make findings and challenge progress persistent for multiple users with accounts and a database. Introduce a review rubric for reasoning, false positives, and evidence.
4. Add a sandboxed Foundry runner with strict time, network, and resource limits. Never run arbitrary repository code on the main web server.
5. Add optional repository mapping and static analysis; keep all model or scanner outputs labeled as candidates until a human verifies them.

## Daily use

Spend 10 minutes mapping actors and assets, 15 minutes identifying assumptions and invariants, 20 minutes writing a test outside the app, and 10 minutes documenting what the test proved. Ask the mentor for a question only after writing your own hypothesis. Export your notes after each session.
